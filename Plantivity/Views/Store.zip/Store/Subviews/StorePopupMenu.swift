import SwiftUI

struct StorePopupMenu: View {
    @EnvironmentObject var themeData: ThemeData
    @EnvironmentObject var storeData: StoreData
    
    @State var count: Double = 0
    @Binding var selectedItem: Item?
    
    var body: some View {
        VStack{
            ColoredText(text: ("How many " + String(selectedItem?.name ?? "item") + "'s do you want to buy?"))
                .padding(.bottom)
            Slider(value: $count, in: 0...5)
            WideButton(text: "Buy", action: {
                let intCount = Int(count)
                storeData.coins -= Int(selectedItem?.price ?? 0) * intCount
                UserDefaults.standard.setValue(storeData.coins , forKey: "coins")
                storeData.setItem(id: Int(selectedItem?.id ?? 0), newCount: intCount)
                selectedItem = nil
            })
        }
        .padding()
        .background(themeData.theme.backgroundColor)
        .cornerRadius(15)
    }
}

