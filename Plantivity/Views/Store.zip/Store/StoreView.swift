//
//  StoreView.swift
//  Plantivity
//
//  Created by Bania on 27.06.22.
//

import SwiftUI

struct StoreView: View {
    @EnvironmentObject var themeData: ThemeData
    @EnvironmentObject var plantsData: PlantsData
    @EnvironmentObject var storeData: StoreData

    
    @Environment(\.presentationMode) var presentationMode
    @State var selectedItem: Item? = nil
    @State var showMenu: Bool = false
    
    var gridItemLayout: [GridItem] = [GridItem(.adaptive(minimum: 100))]
        
    var body: some View {
        
        NavigationView{
            ZStack{
                ScrollView(.vertical, showsIndicators: false){
                    LazyVGrid(columns: gridItemLayout, spacing: 10) {
                        ForEach(storeData.items, id: \.id){ item in
                            StoreItem(item: item, selectedItem: $selectedItem)
                                .padding(.bottom)
                        }
                    }
                    .padding(.top)
                }
                if selectedItem != nil {
                    GeometryReader{ geometry in
                        StorePopupMenu(selectedItem: $selectedItem)
                            .padding(.top, geometry.size.height/3)
                            .padding(.horizontal)
                    }
                    .background(Color(themeData.theme.isDark ? .gray : .black).opacity(0.5))
                    .edgesIgnoringSafeArea(.all)
                    .onTapGesture {
                        selectedItem = nil
                    }
                }
                
            }
            .padding()
            .navigationBarTitle(Text("Shop"), displayMode: NavigationBarItem.TitleDisplayMode.inline)
            .navigationBarItems(
                leading:
                    Button(
                        action: {
                            
                        },
                        label: {
                            HStack{
                                Image(systemName: "dollarsign.circle")
                                Text(String(storeData.coins))
                            }
                        })
                ,
                trailing:
                    NavigationLink(destination: SettingsView()){
                        Image(systemName:"gearshape")
                    }
            )
        }
        .navigationBarColor(backgroundColor: themeData.theme.backgroundColor, textColor: themeData.theme.textColor, accentColor: themeData.theme.accentColor)
    }
}
